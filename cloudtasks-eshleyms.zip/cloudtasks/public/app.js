const form = document.getElementById('taskForm');
const messageDiv = document.getElementById('message');

form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = document.getElementById('title').value.trim();
    const description = document.getElementById('description').value.trim();
    const owner = document.getElementById('owner').value.trim();
    const status = document.getElementById('status').value;

    messageDiv.className = '';
    messageDiv.textContent = '';

    try {
        const response = await fetch('/api/tasks', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ title, description, owner, status })
        });

        const data = await response.json();

        if (response.ok) {
            messageDiv.textContent = '✅ Tarefa salva com sucesso!';
            messageDiv.className = 'success';
            form.reset();
        } else {
            messageDiv.textContent = `❌ Erro: ${data.error}`;
            messageDiv.className = 'error';
        }
    } catch (error) {
        messageDiv.textContent = '❌ Erro de conexão. Tente novamente.';
        messageDiv.className = 'error';
    }
});
