const express = require('express');
const path = require('path');
const { Firestore } = require('@google-cloud/firestore');

const app = express();
const firestore = new Firestore({ databaseId: 'cloudtasks-db' });

app.use(express.json());
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.post('/api/tasks', async (req, res) => {
    try {
        const { title, description, owner, status } = req.body;

        if (!title || !description || !owner || !status) {
            return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
        }

        const taskData = {
            title,
            description,
            owner,
            status,
            createdAt: new Date().toISOString()
        };

        const docRef = await firestore.collection('tasks').add(taskData);

        res.status(201).json({
            success: true,
            message: 'Tarefa salva com sucesso!',
            id: docRef.id
        });

    } catch (error) {
        console.error('Erro ao salvar tarefa:', error);
        res.status(500).json({ error: 'Erro interno ao salvar a tarefa.' });
    }
});

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Servidor iniciado na porta ${PORT}`);
});
