const { Firestore } = require('@google-cloud/firestore');

const firestore = new Firestore({ databaseId: 'cloudtasks-db' });

exports.listTasks = async (req, res) => {
    res.set('Access-Control-Allow-Origin', '*');

    if (req.method === 'OPTIONS') {
        res.set('Access-Control-Allow-Methods', 'GET');
        res.set('Access-Control-Allow-Headers', 'Content-Type');
        return res.status(204).send('');
    }

    try {
        const snapshot = await firestore.collection('tasks').orderBy('createdAt', 'desc').get();

        const tasks = [];
        snapshot.forEach(doc => {
            tasks.push({ id: doc.id, ...doc.data() });
        });

        res.status(200).json({ total: tasks.length, tasks });

    } catch (error) {
        console.error('Erro ao listar tarefas:', error);
        res.status(500).json({ error: 'Erro ao buscar as tarefas.' });
    }
};
